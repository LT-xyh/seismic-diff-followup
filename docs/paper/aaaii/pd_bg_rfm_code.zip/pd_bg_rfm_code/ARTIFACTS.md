# Intended Model Artifact

- Filename: `pd-bg-rfm-final.ckpt`
- SHA-256: not provided because weights are not included

No checkpoint weights are included in this repository. The SHA-256 value must
be supplied with the corresponding weight file if it is distributed separately.
