# PD-BG-RFM Code Appendix

This repository contains the runnable PD-BG-RFM implementation, release
configurations, data preparation utility, training utility, checkpoint-based
evaluation utility, synthetic smoke path, and submission validator.

## Environment

Use Python 3.10. Install a PyTorch build suitable for the target machine, then
install the pinned runtime and test dependencies:

```bash
python -m pip install --upgrade pip
python -m pip install -r reproducibility/requirements.txt
```

The required packages include PyTorch, Lightning, OmegaConf, LMDB, and pytest.
GPU training uses the PyTorch build selected for the available driver and
hardware; the synthetic smoke path runs on CPU.

## OpenFWI Preparation

Place the OpenFWI subset directories in a local source directory. Each selected
subset must provide `depth_vel`, `migrated_image`, `horizon`, and `rms_vel`
arrays. Build LMDB stores with:

```bash
python scripts/aaai27/prepare_openfwi.py \
  --data-root /path/to/OpenFWI \
  --output data/openfwi_lmdb
```

The command writes one LMDB store per configured subset and records preparation
details in `data/openfwi_lmdb/aaai27_prepare_manifest.json`.

## Full Training

After preprocessing, run the release training configuration from the repository
root:

```bash
python scripts/aaai27/train.py --output outputs/train
```

The configuration uses the prepared LMDB stores under `data/openfwi_lmdb`.
Use `--config` to select another included configuration and `--data-root` when
the OpenFWI source location must be supplied explicitly.

## Evaluation

Evaluation is checkpoint-first. Supply a checkpoint path explicitly; this
repository does not include weight files:

```bash
python scripts/aaai27/evaluate.py \
  --checkpoint /path/to/pd-bg-rfm-final.ckpt \
  --output outputs/evaluation
```

The evaluation command writes aggregate metrics and a run manifest below the
requested output directory.

## Offline Smoke Path

The synthetic smoke path does not download data or weights:

```bash
python scripts/aaai27/smoke.py --output outputs/smoke
```

It runs a one-batch CPU training and evaluation flow and writes small runtime
outputs below `outputs/smoke`.

## Submission Check

Run the source-boundary check after creating the anonymous initial commit:

```bash
python scripts/aaai27/validate.py \
  --output reproducibility/generated/submission_validation.json
```

The JSON report confirms the source manifest, artifact exclusions, anonymous
Git metadata, branch name, and single-commit history.

See `REPRODUCIBILITY.md` for output expectations and reproducibility limits.
