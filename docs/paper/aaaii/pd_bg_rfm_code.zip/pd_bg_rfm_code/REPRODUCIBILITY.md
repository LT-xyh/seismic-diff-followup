# Reproducibility

## Runtime Setup

Use Python 3.10 and install the pinned packages in
`reproducibility/requirements.txt`. The environment includes PyTorch,
Lightning, OmegaConf, LMDB, and pytest. Select the PyTorch wheel that matches
the target accelerator and driver before installing the remaining packages.

## Data Preparation

Prepare local OpenFWI arrays with:

```bash
python scripts/aaai27/prepare_openfwi.py \
  --data-root /path/to/OpenFWI \
  --output data/openfwi_lmdb
```

The generated LMDB root contains a store and manifest for every configured
subset. The preparation manifest records the source root, split seed, well
seed, selected modalities, sample counts, and input digests.

## Training

Run the full configuration after preparation:

```bash
python scripts/aaai27/train.py --output outputs/train
```

Expected training outputs include checkpoints, Lightning logs, diagnostics,
and evaluation files beneath `outputs/train`. The run configuration fixes the
training seed, split seed, and well seed. A full run requires the selected
OpenFWI data and sufficient accelerator memory.

## Checkpoint-Based Evaluation

Use a user-supplied checkpoint for evaluation:

```bash
python scripts/aaai27/evaluate.py \
  --checkpoint /path/to/pd-bg-rfm-final.ckpt \
  --output outputs/evaluation
```

Expected evaluation outputs include `metrics.csv`, `summary.json`, and a run
manifest in the chosen output directory. Checkpoint weights are intentionally
absent from this repository; `ARTIFACTS.md` records the intended filename and
hash status.

## Offline Smoke Path

Run the compact synthetic workflow without a network connection, OpenFWI data,
or checkpoint weights:

```bash
python scripts/aaai27/smoke.py --output outputs/smoke
```

Expected smoke outputs include a small checkpoint, evaluation metrics, and a
run manifest beneath `outputs/smoke`.

## Limits

The included seeds control Python, NumPy, PyTorch, and data-loader randomness,
but bitwise-identical results are not guaranteed across accelerator models,
drivers, distributed runtimes, or library versions. Runtime duration and
numerical variation depend on the selected hardware and PyTorch build. The
repository contains source code and configurations only; users provide OpenFWI
data and any checkpoint used for evaluation.
