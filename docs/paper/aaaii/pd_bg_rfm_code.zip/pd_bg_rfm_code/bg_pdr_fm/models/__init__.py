"""Public model exports for the self-contained BG-PDR-FM package."""

from .adapters import ConditionAdapters
from .calibrator import RhoCalibrator
from .codecs import build_latent_codec
from .contrastive import build_contrastive_loss, build_wavelet_anchor
from .encoder import PhysicsDecoupledEncoder
from .filters import LowHighPassFilter
from .generators import BackgroundEstimator, ResidualFlowGenerator
from .types import PredictionBatch

__all__ = [
    "BackgroundEstimator",
    "ConditionAdapters",
    "LowHighPassFilter",
    "PhysicsDecoupledEncoder",
    "PredictionBatch",
    "ResidualFlowGenerator",
    "RhoCalibrator",
    "build_contrastive_loss",
    "build_latent_codec",
    "build_wavelet_anchor",
]
