"""Latent codec abstractions used by background and residual generators."""

from __future__ import annotations

from typing import Protocol

import torch
import torch.nn as nn
import torch.nn.functional as F


class LatentCodec(Protocol):
    """Minimal latent interface required by BG-PDR-FM generators."""

    def encode(self, image: torch.Tensor, deterministic: bool = True) -> torch.Tensor:
        ...

    def decode(self, latent: torch.Tensor, out_hw: tuple[int, int]) -> torch.Tensor:
        ...


class SimpleLatentCodec(nn.Module):
    """Small trainable codec for smoke runs and checkpoint-free validation."""

    codec_type = "simple"
    trainable_codec = True

    def __init__(self, image_channels: int = 1, latent_channels: int = 16, latent_hw: tuple[int, int] = (16, 16)) -> None:
        super().__init__()
        self.latent_channels = int(latent_channels)
        self.latent_hw = tuple(latent_hw)
        self.encoder = nn.Sequential(
            nn.Conv2d(image_channels, 32, kernel_size=3, padding=1),
            nn.SiLU(),
            nn.Conv2d(32, latent_channels, kernel_size=3, padding=1),
        )
        self.decoder = nn.Sequential(
            nn.Conv2d(latent_channels, 32, kernel_size=3, padding=1),
            nn.SiLU(),
            nn.Conv2d(32, image_channels, kernel_size=3, padding=1),
        )

    def encode(self, image: torch.Tensor, deterministic: bool = True) -> torch.Tensor:
        del deterministic
        x = F.interpolate(image, size=self.latent_hw, mode="bilinear", align_corners=False)
        return self.encoder(x)

    def decode(self, latent: torch.Tensor, out_hw: tuple[int, int] = (70, 70)) -> torch.Tensor:
        x = self.decoder(latent)
        return F.interpolate(x, size=out_hw, mode="bilinear", align_corners=False)


class IdentityLatentCodec(nn.Module):
    """Parameter-free codec that runs residual generation directly in image space."""

    codec_type = "identity"
    trainable_codec = False

    def __init__(self, image_channels: int = 1, latent_channels: int = 1, latent_hw: tuple[int, int] = (70, 70)) -> None:
        super().__init__()
        self.image_channels = int(image_channels)
        self.latent_channels = int(latent_channels)
        self.latent_hw = tuple(int(v) for v in latent_hw)
        if self.image_channels <= 0 or self.latent_channels <= 0:
            raise ValueError("IdentityLatentCodec channel counts must be positive.")
        if self.image_channels != self.latent_channels:
            raise ValueError(
                "IdentityLatentCodec requires image_channels == latent_channels; "
                f"got image_channels={self.image_channels}, latent_channels={self.latent_channels}."
            )
        if len(self.latent_hw) != 2 or min(self.latent_hw) <= 0:
            raise ValueError(f"IdentityLatentCodec latent_hw must be a positive HW pair, got {latent_hw!r}.")

    def _validate(self, tensor: torch.Tensor, label: str) -> None:
        expected = (self.latent_channels, *self.latent_hw)
        if tensor.ndim != 4 or tuple(tensor.shape[1:]) != expected:
            raise ValueError(
                f"IdentityLatentCodec {label} expected BCHW with trailing shape {expected}, "
                f"got {tuple(tensor.shape)}."
            )

    def encode(self, image: torch.Tensor, deterministic: bool = True) -> torch.Tensor:
        del deterministic
        self._validate(image, "encode")
        return image

    def decode(self, latent: torch.Tensor, out_hw: tuple[int, int]) -> torch.Tensor:
        self._validate(latent, "decode")
        if tuple(int(v) for v in out_hw) != self.latent_hw:
            raise ValueError(
                f"IdentityLatentCodec decode out_hw must match latent_hw={self.latent_hw}, got {out_hw!r}."
            )
        return latent



def build_latent_codec(
    codec_type: str = "simple",
    latent_channels: int = 16,
    latent_hw: tuple[int, int] = (16, 16),
) -> nn.Module:
    codec_type = str(codec_type).lower()
    if codec_type == "simple":
        return SimpleLatentCodec(latent_channels=latent_channels, latent_hw=latent_hw)
    if codec_type == "identity":
        return IdentityLatentCodec(latent_channels=latent_channels, latent_hw=latent_hw)
    raise ValueError("Only supported codec types are: simple, identity")
