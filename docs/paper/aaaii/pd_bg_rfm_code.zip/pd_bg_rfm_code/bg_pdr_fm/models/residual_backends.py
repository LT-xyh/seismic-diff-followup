"""Residual flow-matching backend abstractions."""

from __future__ import annotations

from typing import Protocol

import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualGeneratorBackend(Protocol):
    backend_name: str

    def training_loss(
        self,
        z_res: torch.Tensor,
        cond: torch.Tensor,
        alpha_hat: torch.Tensor | None = None,
        loss_type: str = "mse",
    ) -> dict[str, torch.Tensor]:
        ...

    def sample(self, cond: torch.Tensor, x_size: tuple[int, ...], steps: int) -> torch.Tensor:
        ...

    def sample_with_trace(
        self,
        cond: torch.Tensor,
        x_size: tuple[int, ...],
        steps: int,
        noise: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        ...


class _VelocityField(nn.Module):
    def __init__(self, latent_channels: int = 16, cond_channels: int = 64, hidden_channels: int = 96) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(latent_channels + cond_channels, hidden_channels, kernel_size=3, padding=1),
            nn.GroupNorm(num_groups=min(8, hidden_channels), num_channels=hidden_channels),
            nn.SiLU(),
            nn.Conv2d(hidden_channels, hidden_channels, kernel_size=3, padding=1),
            nn.SiLU(),
            nn.Conv2d(hidden_channels, latent_channels, kernel_size=1),
        )

    def forward(self, z_t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        return self.net(torch.cat([z_t, cond], dim=1))


class _SinusoidalTimeEmbedding(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.dim = int(dim)

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        half = max(self.dim // 2, 1)
        freqs = torch.exp(
            torch.linspace(
                0.0,
                -torch.log(t.new_tensor(10000.0)),
                half,
                device=t.device,
                dtype=t.dtype,
            )
        )
        args = t.float().to(dtype=t.dtype).view(-1, 1) * freqs.view(1, -1)
        emb = torch.cat([torch.sin(args), torch.cos(args)], dim=1)
        if emb.shape[1] < self.dim:
            emb = F.pad(emb, (0, self.dim - emb.shape[1]))
        return emb[:, : self.dim]


class _FiLMResBlock(nn.Module):
    def __init__(self, channels: int, cond_channels: int, time_dim: int) -> None:
        super().__init__()
        groups = min(8, int(channels))
        self.norm1 = nn.GroupNorm(num_groups=groups, num_channels=channels)
        self.conv1 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        self.norm2 = nn.GroupNorm(num_groups=groups, num_channels=channels)
        self.conv2 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        self.time_proj = nn.Linear(time_dim, channels * 2)
        self.cond_proj = nn.Conv2d(cond_channels, channels * 2, kernel_size=1)

    def forward(self, x: torch.Tensor, cond: torch.Tensor, time_emb: torch.Tensor) -> torch.Tensor:
        if tuple(cond.shape[-2:]) != tuple(x.shape[-2:]):
            cond = F.interpolate(cond, size=x.shape[-2:], mode="bilinear", align_corners=False)
        gamma_beta = self.cond_proj(cond) + self.time_proj(time_emb).view(x.shape[0], -1, 1, 1)
        gamma, beta = gamma_beta.chunk(2, dim=1)
        h = self.conv1(F.silu(self.norm1(x)))
        h = h * (1.0 + gamma) + beta
        h = self.conv2(F.silu(self.norm2(h)))
        return x + h


class _LatentUNetFiLMField(nn.Module):
    def __init__(self, latent_channels: int, cond_channels: int, hidden_channels: int) -> None:
        super().__init__()
        hidden = int(hidden_channels)
        mid = max(hidden * 2, hidden)
        self.time_embed = nn.Sequential(
            _SinusoidalTimeEmbedding(hidden),
            nn.Linear(hidden, hidden * 4),
            nn.SiLU(),
            nn.Linear(hidden * 4, hidden),
        )
        self.in_proj = nn.Conv2d(latent_channels, hidden, kernel_size=3, padding=1)
        self.down_block = _FiLMResBlock(hidden, cond_channels, hidden)
        self.downsample = nn.Conv2d(hidden, mid, kernel_size=3, stride=2, padding=1)
        self.mid_block = _FiLMResBlock(mid, cond_channels, hidden)
        self.upsample = nn.ConvTranspose2d(mid, hidden, kernel_size=4, stride=2, padding=1)
        self.up_block = _FiLMResBlock(hidden, cond_channels, hidden)
        self.out_norm = nn.GroupNorm(num_groups=min(8, hidden), num_channels=hidden)
        self.out_proj = nn.Conv2d(hidden, latent_channels, kernel_size=3, padding=1)

    def forward(self, z_t: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        time_emb = self.time_embed(t)
        skip = self.in_proj(z_t)
        h = self.down_block(skip, cond, time_emb)
        h = self.downsample(h)
        h = self.mid_block(h, cond, time_emb)
        h = self.upsample(h)
        if tuple(h.shape[-2:]) != tuple(skip.shape[-2:]):
            h = F.interpolate(h, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        h = self.up_block(h + skip, cond, time_emb)
        return self.out_proj(F.silu(self.out_norm(h)))


def _weighted_mse_loss_map(
    prediction: torch.Tensor,
    target: torch.Tensor,
    alpha_hat: torch.Tensor | None = None,
) -> torch.Tensor:
    loss_map = (prediction - target) ** 2
    if alpha_hat is not None:
        loss_map = loss_map * (1.0 + alpha_hat.view(-1, 1, 1, 1))
    return loss_map.mean()


class SimpleResidualFMBackend(nn.Module):
    """Small linear Flow Matching backend for smoke runs."""

    backend_name = "simple_fm"

    def __init__(self, latent_channels: int = 16, cond_channels: int = 64, hidden_channels: int = 96) -> None:
        super().__init__()
        self.field = _VelocityField(
            latent_channels=latent_channels,
            cond_channels=cond_channels,
            hidden_channels=hidden_channels,
        )

    def training_loss(
        self,
        z_res: torch.Tensor,
        cond: torch.Tensor,
        alpha_hat: torch.Tensor | None = None,
        loss_type: str = "mse",
    ) -> dict[str, torch.Tensor]:
        if loss_type != "mse":
            raise ValueError(f"simple_fm residual backend only supports loss_type='mse', got {loss_type!r}.")
        batch_size = z_res.shape[0]
        z0 = torch.randn_like(z_res)
        t = torch.rand(batch_size, device=z_res.device, dtype=z_res.dtype)
        t_view = t.view(-1, *([1] * (z_res.ndim - 1)))
        z_t = (1.0 - t_view) * z0 + t_view * z_res
        target = z_res - z0
        pred = self.field(z_t, cond)
        loss = _weighted_mse_loss_map(pred, target, alpha_hat=alpha_hat)
        z_res_pred = z_t + (1.0 - t_view) * pred
        return {
            "loss": loss,
            "velocity_pred": pred,
            "velocity_target": target,
            "z_res_pred": z_res_pred,
            "t": t,
            "x_t": z_t,
            "x0": z0,
        }

    @torch.no_grad()
    def sample(self, cond: torch.Tensor, x_size: tuple[int, ...], steps: int) -> torch.Tensor:
        z_t = torch.randn(x_size, device=cond.device, dtype=cond.dtype)
        dt = 1.0 / float(max(steps, 1))
        for _ in range(max(steps, 1)):
            z_t = z_t + dt * self.field(z_t, cond)
        return z_t


class UNetFiLMResidualFMBackend(nn.Module):
    """Conditional latent Flow Matching backend with U-Net and FiLM conditioning."""

    backend_name = "unet_fm_film"

    def __init__(self, latent_channels: int = 16, cond_channels: int = 64, hidden_channels: int = 128) -> None:
        super().__init__()
        self.field = _LatentUNetFiLMField(
            latent_channels=latent_channels,
            cond_channels=cond_channels,
            hidden_channels=hidden_channels,
        )

    def training_loss(
        self,
        z_res: torch.Tensor,
        cond: torch.Tensor,
        alpha_hat: torch.Tensor | None = None,
        loss_type: str = "mse",
    ) -> dict[str, torch.Tensor]:
        if loss_type != "mse":
            raise ValueError(f"unet_fm_film residual backend only supports loss_type='mse', got {loss_type!r}.")
        batch_size = z_res.shape[0]
        z0 = torch.randn_like(z_res)
        t = torch.rand(batch_size, device=z_res.device, dtype=z_res.dtype)
        t_view = t.view(-1, *([1] * (z_res.ndim - 1)))
        z_t = (1.0 - t_view) * z0 + t_view * z_res
        target = z_res - z0
        pred = self.field(z_t, t, cond)
        loss = _weighted_mse_loss_map(pred, target, alpha_hat=alpha_hat)
        z_res_pred = z_t + (1.0 - t_view) * pred
        return {
            "loss": loss,
            "velocity_pred": pred,
            "velocity_target": target,
            "z_res_pred": z_res_pred,
            "t": t,
            "x_t": z_t,
            "x0": z0,
        }

    @staticmethod
    def _initial_state(
        cond: torch.Tensor,
        x_size: tuple[int, ...],
        noise: torch.Tensor | None,
    ) -> torch.Tensor:
        if noise is None:
            return torch.randn(x_size, device=cond.device, dtype=cond.dtype)
        if tuple(noise.shape) != tuple(x_size):
            raise ValueError(f"noise shape {tuple(noise.shape)} does not match x_size {tuple(x_size)}.")
        if noise.device != cond.device or noise.dtype != cond.dtype:
            raise ValueError(
                "noise must use the same device and dtype as cond; "
                f"got noise=({noise.device}, {noise.dtype}), cond=({cond.device}, {cond.dtype})."
            )
        return noise

    @torch.no_grad()
    def sample(
        self,
        cond: torch.Tensor,
        x_size: tuple[int, ...],
        steps: int,
        noise: torch.Tensor | None = None,
    ) -> torch.Tensor:
        z_t = self._initial_state(cond, x_size, noise)
        steps = int(max(steps, 1))
        dt = 1.0 / float(steps)
        for idx in range(steps):
            t_value = z_t.new_full((z_t.shape[0],), float(idx) / float(steps))
            z_t = z_t + dt * self.field(z_t, t_value, cond)
        return z_t

    @torch.no_grad()
    def sample_with_trace(
        self,
        cond: torch.Tensor,
        x_size: tuple[int, ...],
        steps: int,
        noise: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """Run the production Euler sampler while retaining every FM state."""
        z_t = self._initial_state(cond, x_size, noise)
        steps = int(max(steps, 1))
        dt = 1.0 / float(steps)
        states = [z_t]
        velocities: list[torch.Tensor] = []
        deltas: list[torch.Tensor] = []
        times: list[torch.Tensor] = []
        for idx in range(steps):
            t_value = z_t.new_full((z_t.shape[0],), float(idx) / float(steps))
            velocity = self.field(z_t, t_value, cond)
            delta = dt * velocity
            velocities.append(velocity)
            deltas.append(delta)
            times.append(t_value)
            z_t = z_t + delta
            states.append(z_t)
        return {
            "states": torch.stack(states, dim=0),
            "velocities": torch.stack(velocities, dim=0),
            "deltas": torch.stack(deltas, dim=0),
            "times": torch.stack(times, dim=0),
            "condition": cond,
        }


class DirectResidualPredictorBackend(nn.Module):
    """Deterministic latent residual predictor for teacher-forced diagnostics."""

    backend_name = "direct_predictor"

    def __init__(self, latent_channels: int = 16, cond_channels: int = 64, hidden_channels: int = 96) -> None:
        super().__init__()
        self.field = _VelocityField(
            latent_channels=latent_channels,
            cond_channels=cond_channels,
            hidden_channels=hidden_channels,
        )
        self.latent_channels = int(latent_channels)

    def _zero_latent(self, cond: torch.Tensor, x_size: tuple[int, ...]) -> torch.Tensor:
        return torch.zeros(x_size, device=cond.device, dtype=cond.dtype)

    def training_loss(
        self,
        z_res: torch.Tensor,
        cond: torch.Tensor,
        alpha_hat: torch.Tensor | None = None,
        loss_type: str = "mse",
    ) -> dict[str, torch.Tensor]:
        if loss_type != "mse":
            raise ValueError(f"direct_predictor residual backend only supports loss_type='mse', got {loss_type!r}.")
        z0 = self._zero_latent(cond, tuple(z_res.shape))
        pred = self.field(z0, cond)
        loss = _weighted_mse_loss_map(pred, z_res, alpha_hat=alpha_hat)
        return {
            "loss": loss,
            "velocity_pred": pred,
            "velocity_target": z_res,
            "z_res_pred": pred,
            "t": torch.zeros((z_res.shape[0],), device=z_res.device, dtype=z_res.dtype),
            "x_t": z0,
            "x0": z0,
        }

    @torch.no_grad()
    def sample(self, cond: torch.Tensor, x_size: tuple[int, ...], steps: int) -> torch.Tensor:
        del steps
        return self.field(self._zero_latent(cond, tuple(x_size)), cond)


def build_residual_backend(
    backend: str = "simple_fm",
    latent_channels: int = 16,
    cond_channels: int = 64,
    hidden_channels: int = 96,
) -> nn.Module:
    backend = str(backend).lower()
    if backend == "simple_fm":
        return SimpleResidualFMBackend(
            latent_channels=latent_channels,
            cond_channels=cond_channels,
            hidden_channels=hidden_channels,
        )
    if backend == "unet_fm_film":
        return UNetFiLMResidualFMBackend(
            latent_channels=latent_channels,
            cond_channels=cond_channels,
            hidden_channels=hidden_channels,
        )
    if backend == "direct_predictor":
        return DirectResidualPredictorBackend(
            latent_channels=latent_channels,
            cond_channels=cond_channels,
            hidden_channels=hidden_channels,
        )
    raise ValueError("Only supported residual backends are: simple_fm, unet_fm_film, direct_predictor")
