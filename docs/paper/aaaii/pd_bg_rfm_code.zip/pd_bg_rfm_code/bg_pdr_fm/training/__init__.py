"""Lazy training entrypoint exports for BG-PDR-FM."""


def train_bg_pdr_fm_main(*args, **kwargs):
    from .train_bg_pdr_fm import main

    return main(*args, **kwargs)

__all__ = ["train_bg_pdr_fm_main"]
