"""Utilities for the standalone source distribution."""
