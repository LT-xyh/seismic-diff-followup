"""Validate the standalone source-submission boundary."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path, PurePosixPath
from typing import Any

import yaml


REPO_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = Path("reproducibility/source_manifest.yaml")
MANIFEST_LIST_FIELDS = ("source", "configs", "tests", "documentation")
EXPECTED_ENTRYPOINTS = frozenset({"prepare_openfwi", "train", "evaluate", "smoke", "validate"})
EXPECTED_GIT_IDENTITY = ("Anonymous", "anonymous@example.com")
EXPECTED_INITIAL_SUBJECT = "Initial anonymous code appendix"
FORBIDDEN_ROOTS = frozenset(
    {
        "data",
        "datasets",
        "checkpoints",
        "ckpt",
        "logs",
        "outputs",
        "release_outputs",
        "reports",
        "generated",
    }
)
FORBIDDEN_PARTS = frozenset(
    {
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        ".agents",
    }
)
FORBIDDEN_SUFFIXES = frozenset(
    {".ckpt", ".pt", ".pth", ".lmdb", ".mdb", ".npy", ".npz", ".pdf", ".tex", ".bib"}
)
DISALLOWED_TEXT = (b"co" + b"dex",)


class ReleaseValidationError(RuntimeError):
    """Raised when the standalone source boundary is invalid."""


def _load_yaml(path: Path) -> dict[str, Any]:
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ReleaseValidationError(f"cannot read manifest: {path}") from exc
    except yaml.YAMLError as exc:
        raise ReleaseValidationError(f"invalid manifest YAML: {path}") from exc
    if not isinstance(payload, dict):
        raise ReleaseValidationError("source manifest must be a YAML mapping")
    return payload


def _validate_relative_path(value: object, *, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ReleaseValidationError(f"{field} path must be a non-empty string: {value!r}")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or value.startswith("./"):
        raise ReleaseValidationError(f"{field} path must be repository-relative: {value!r}")
    return path.as_posix()


def _is_forbidden_path(value: str) -> bool:
    path = PurePosixPath(value)
    if path.parts and path.parts[0] in FORBIDDEN_ROOTS:
        return True
    if FORBIDDEN_PARTS.intersection(path.parts):
        return True
    return path.suffix.lower() in FORBIDDEN_SUFFIXES


def _git(root: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        ["git", *args],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    if check and result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        raise ReleaseValidationError(f"git {' '.join(args)} failed: {detail}")
    return result


def _is_ignored(root: Path, relative_path: str) -> bool:
    return _git(root, "check-ignore", "--quiet", "--no-index", "--", relative_path, check=False).returncode == 0


def _manifest_paths(root: Path) -> tuple[dict[str, Any], set[str]]:
    manifest_file = root / MANIFEST_PATH
    if not manifest_file.is_file():
        raise ReleaseValidationError(f"missing source manifest: {MANIFEST_PATH.as_posix()}")
    manifest = _load_yaml(manifest_file)
    if manifest.get("version") != 1:
        raise ReleaseValidationError("source manifest version must be 1")

    paths: set[str] = set()
    for field in MANIFEST_LIST_FIELDS:
        values = manifest.get(field)
        if not isinstance(values, list) or not values:
            raise ReleaseValidationError(f"source manifest {field} must be a non-empty list")
        for value in values:
            relative_path = _validate_relative_path(value, field=field)
            if relative_path in paths:
                raise ReleaseValidationError(f"source manifest duplicates path: {relative_path}")
            paths.add(relative_path)

    entrypoints = manifest.get("entrypoints")
    if not isinstance(entrypoints, dict) or set(entrypoints) != EXPECTED_ENTRYPOINTS:
        names = ", ".join(sorted(EXPECTED_ENTRYPOINTS))
        raise ReleaseValidationError(f"source manifest entrypoints must contain exactly: {names}")
    for name, value in entrypoints.items():
        relative_path = _validate_relative_path(value, field=f"entrypoints.{name}")
        if relative_path in paths:
            raise ReleaseValidationError(f"source manifest duplicates path: {relative_path}")
        paths.add(relative_path)

    for relative_path in sorted(paths):
        if _is_forbidden_path(relative_path):
            raise ReleaseValidationError(f"forbidden path in source manifest: {relative_path}")
        source_path = root / relative_path
        if not source_path.is_file():
            raise ReleaseValidationError(f"source manifest path is missing: {relative_path}")
        if _is_ignored(root, relative_path):
            raise ReleaseValidationError(f"source manifest path is ignored by Git: {relative_path}")
    return manifest, paths


def _tracked_regular_files(root: Path) -> list[str]:
    result = _git(root, "ls-files", "-z")
    files: list[str] = []
    for value in result.stdout.split("\0"):
        if not value:
            continue
        relative_path = _validate_relative_path(value, field="tracked")
        path = root / relative_path
        if not path.is_file() or path.is_symlink():
            raise ReleaseValidationError(f"tracked path is not a regular file: {relative_path}")
        files.append(relative_path)
    return files


def _validate_tracked_paths(tracked_files: list[str]) -> None:
    for relative_path in tracked_files:
        if _is_forbidden_path(relative_path):
            raise ReleaseValidationError(f"forbidden tracked path: {relative_path}")


def _validate_manifest_completeness(tracked_files: list[str], manifest_paths: set[str]) -> None:
    missing = sorted(set(tracked_files).difference(manifest_paths))
    if missing:
        raise ReleaseValidationError(f"tracked source path missing from source manifest: {', '.join(missing)}")


def _validate_disallowed_text(root: Path, tracked_files: list[str]) -> None:
    for relative_path in tracked_files:
        content = (root / relative_path).read_bytes().lower()
        if any(token in content for token in DISALLOWED_TEXT):
            raise ReleaseValidationError(f"disallowed text in tracked file: {relative_path}")


def _contains_disallowed_text(value: str) -> bool:
    content = value.encode("utf-8").lower()
    return any(token in content for token in DISALLOWED_TEXT)


def _validate_git_state(root: Path) -> dict[str, Any]:
    name = _git(root, "config", "--local", "--get", "user.name").stdout.strip()
    email = _git(root, "config", "--local", "--get", "user.email").stdout.strip()
    if (name, email) != EXPECTED_GIT_IDENTITY:
        raise ReleaseValidationError("Git identity must be Anonymous <anonymous@example.com>")

    remotes = _git(root, "remote").stdout.split()
    if remotes:
        raise ReleaseValidationError(f"repository must not have remotes: {', '.join(remotes)}")

    refs = _git(root, "for-each-ref", "--format=%(refname)").stdout.splitlines()
    if refs != ["refs/heads/main"]:
        raise ReleaseValidationError(f"repository references must be exactly refs/heads/main, got {refs!r}")

    branch = _git(root, "branch", "--show-current").stdout.strip()
    if branch != "main":
        raise ReleaseValidationError(f"repository branch must be main, got {branch!r}")

    count_text = _git(root, "rev-list", "--count", "--all").stdout.strip()
    try:
        commit_count = int(count_text)
    except ValueError as exc:
        raise ReleaseValidationError(f"invalid Git commit count: {count_text!r}") from exc
    if commit_count != 1:
        raise ReleaseValidationError(f"repository must contain exactly one commit, got {commit_count}")

    head_output = _git(root, "show", "-s", "--format=%s%x00%an%x00%ae%x00%cn%x00%ce", "HEAD").stdout
    head_fields = head_output.rstrip("\n").split("\0")
    if len(head_fields) < 5:
        raise ReleaseValidationError("cannot read initial commit metadata")
    subject, author_name, author_email, committer_name, committer_email = head_fields[:5]
    if subject != EXPECTED_INITIAL_SUBJECT:
        raise ReleaseValidationError(f"initial commit subject must be {EXPECTED_INITIAL_SUBJECT!r}")
    if (author_name, author_email) != EXPECTED_GIT_IDENTITY or (
        committer_name,
        committer_email,
    ) != EXPECTED_GIT_IDENTITY:
        raise ReleaseValidationError("initial commit identity must be Anonymous <anonymous@example.com>")

    local_config = _git(root, "config", "--local", "--list").stdout
    history = _git(
        root,
        "log",
        "--all",
        "--format=%s%x00%b%x00%an%x00%ae%x00%cn%x00%ce",
    ).stdout
    if _contains_disallowed_text(local_config) or _contains_disallowed_text(history):
        raise ReleaseValidationError("disallowed text in Git metadata")

    return {
        "branch": branch,
        "commit_count": commit_count,
        "remotes": remotes,
        "refs": refs,
        "head_subject": subject,
    }


def _resolve_output_path(root: Path, output: str | Path | None) -> Path:
    if output is None:
        return root / "reproducibility" / "generated" / "submission_validation.json"
    path = Path(output)
    return path if path.is_absolute() else root / path


def _write_report(path: Path, report: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def validate_submission(
    *,
    repo_root: str | Path | None = None,
    config_path: str | Path | None = None,
    output: str | Path | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Validate the source-only repository and write a JSON report."""
    del force
    root = Path(repo_root).resolve() if repo_root is not None else REPO_ROOT
    manifest, manifest_paths = _manifest_paths(root)
    if config_path is not None:
        requested = Path(config_path)
        requested = requested if requested.is_absolute() else root / requested
        if not requested.is_file():
            raise ReleaseValidationError(f"requested config is missing: {requested}")

    tracked_files = _tracked_regular_files(root)
    _validate_tracked_paths(tracked_files)
    _validate_manifest_completeness(tracked_files, manifest_paths)
    _validate_disallowed_text(root, tracked_files)
    git_state = _validate_git_state(root)
    output_path = _resolve_output_path(root, output)
    if output is None and not _is_ignored(root, output_path.relative_to(root).as_posix()):
        raise ReleaseValidationError("default report path is not ignored by Git")

    report = {
        "version": 1,
        "status": "pass",
        "manifest": MANIFEST_PATH.as_posix(),
        "tracked_file_count": len(tracked_files),
        "repository": git_state,
        "checks": {
            "manifest": "pass",
            "manifest_tracking": "pass",
            "tracked_paths": "pass",
            "disallowed_text": "pass",
            "git_identity": "pass",
            "git_remotes": "pass",
            "git_references": "pass",
            "git_history": "pass",
            "branch": "pass",
            "git_commit_subject": "pass",
            "git_commit_identity": "pass",
            "git_metadata_scan": "pass",
        },
    }
    _write_report(output_path, report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=None)
    parser.add_argument("--output", default=None)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args(argv)
    try:
        report = validate_submission(config_path=args.config, output=args.output, force=bool(args.force))
    except ReleaseValidationError as exc:
        print(f"submission validation failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps({"status": report["status"], "output": args.output}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
