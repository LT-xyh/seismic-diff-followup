"""Evaluate a canonical AAAI27 checkpoint on the held-out test split."""

from __future__ import annotations

import argparse

from common import add_release_arguments, emit_dry_run, resolve_release_config


DEFAULT_CONFIG = "bg_pdr_fm/configs/release/aaai27/evaluate.yaml"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    add_release_arguments(parser, default_config=DEFAULT_CONFIG)
    parser.add_argument("--checkpoint", help="Path to the full-model checkpoint to evaluate.")
    args = parser.parse_args(argv)
    config_path, conf = resolve_release_config(args)
    if args.dry_run:
        emit_dry_run(config_path, conf)
        return 0
    if args.checkpoint is None:
        parser.error("--checkpoint is required unless --dry-run is used")
    conf.evaluation.checkpoints.full = args.checkpoint

    from bg_pdr_fm.evaluation.evaluate_bg_pdr_fm import run_evaluation

    run_evaluation(conf)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
