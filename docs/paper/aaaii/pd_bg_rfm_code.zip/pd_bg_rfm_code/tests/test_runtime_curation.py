"""Regression tests for the standalone runtime surface."""

from __future__ import annotations

import importlib
import inspect
from pathlib import Path
import subprocess
import sys

import pytest
from omegaconf import OmegaConf


@pytest.mark.parametrize(
    "package_name",
    [
        "bg_pdr_fm.data",
        "bg_pdr_fm.models",
        "bg_pdr_fm.lightning",
        "bg_pdr_fm.evaluation",
        "bg_pdr_fm.training",
    ],
)
def test_runtime_packages_import_without_omitted_modules(package_name: str) -> None:
    assert importlib.import_module(package_name) is not None


def test_retained_data_exports_load_without_omitted_source_modules() -> None:
    data = importlib.import_module("bg_pdr_fm.data")

    assert data.OpenFWIBGDataset is not None
    assert data.SyntheticBGDataset is not None


def test_build_dataset_accepts_synthetic() -> None:
    from bg_pdr_fm.data.datasets import SyntheticBGDataset
    from bg_pdr_fm.training.train_bg_pdr_fm import build_dataset

    conf = OmegaConf.create({"data": {"name": "synthetic", "train_length": 3}})

    dataset = build_dataset(conf, "train")

    assert isinstance(dataset, SyntheticBGDataset)
    assert len(dataset) == 3


def test_build_dataset_rejects_removed_dataset_name() -> None:
    from bg_pdr_fm.training.train_bg_pdr_fm import build_dataset

    conf = OmegaConf.create({"data": {"name": "marmousi"}})

    with pytest.raises(ValueError, match=r"(?i)only supported datasets.*synthetic.*openfwi"):
        build_dataset(conf, "train")


def test_build_latent_codec_accepts_simple_and_identity() -> None:
    from bg_pdr_fm.models.codecs import build_latent_codec

    simple = build_latent_codec(codec_type="simple", latent_channels=1, latent_hw=(8, 8))
    identity = build_latent_codec(codec_type="identity", latent_channels=1, latent_hw=(8, 8))

    assert simple.codec_type == "simple"
    assert identity.codec_type == "identity"


def test_release_smoke_config_constructs_lightning_without_removed_codec_keys() -> None:
    from bg_pdr_fm.lightning import BGPDRFMLightning
    from bg_pdr_fm.training.benchmark_config import load_benchmark_config

    config_path = Path(__file__).parents[1] / "bg_pdr_fm/configs/release/aaai27/smoke.yaml"
    conf = load_benchmark_config(config_path)

    assert BGPDRFMLightning(conf) is not None
    assert "codec_checkpoint" not in conf.model
    assert "codec_module_path" not in conf.model


@pytest.mark.parametrize("codec_type", ["autoencoder", "vae"])
def test_build_latent_codec_rejects_removed_codec_names(codec_type: str) -> None:
    from bg_pdr_fm.models.codecs import build_latent_codec

    with pytest.raises(ValueError, match=r"Only supported codec types are: simple, identity"):
        build_latent_codec(codec_type=codec_type)


def test_build_residual_backend_accepts_release_backend() -> None:
    from bg_pdr_fm.models.residual_backends import build_residual_backend

    backend = build_residual_backend(
        backend="unet_fm_film",
        latent_channels=1,
        cond_channels=2,
        hidden_channels=8,
    )

    assert backend.backend_name == "unet_fm_film"


@pytest.mark.parametrize("backend_name", ["simple_fm", "unet_fm_film", "direct_predictor"])
def test_build_residual_backend_accepts_each_supported_backend(backend_name: str) -> None:
    from bg_pdr_fm.models.residual_backends import build_residual_backend

    backend = build_residual_backend(
        backend=backend_name,
        latent_channels=1,
        cond_channels=2,
        hidden_channels=8,
    )

    assert backend.backend_name == backend_name


def test_evaluation_requires_checkpoint_except_for_dry_run() -> None:
    repo_root = Path(__file__).parents[1]
    script = repo_root / "scripts/aaai27/evaluate.py"

    missing_checkpoint = subprocess.run(
        [sys.executable, str(script)],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )
    dry_run = subprocess.run(
        [sys.executable, str(script), "--dry-run"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )

    assert missing_checkpoint.returncode == 2
    assert "--checkpoint" in missing_checkpoint.stderr
    assert dry_run.returncode == 0


def test_evaluator_defaults_to_included_release_config_without_removed_paths() -> None:
    from bg_pdr_fm.evaluation.evaluate_bg_pdr_fm import main as evaluate_main

    repo_root = Path(__file__).parents[1]
    expected_config = "bg_pdr_fm/configs/release/aaai27/evaluate.yaml"
    default_config = inspect.signature(evaluate_main).parameters["config_path"].default

    assert default_config == expected_config
    assert (repo_root / default_config).is_file()

    removed_paths = (
        "bg_pdr_fm/configs/bg_pdr_fm.yaml",
        "bg_pdr_fm/configs/fast_run.yaml",
        "bg_pdr_fm/configs/openfwi_lmdb_train.yaml",
    )
    source_paths = (
        repo_root / "bg_pdr_fm/evaluation/evaluate_bg_pdr_fm.py",
        repo_root / "bg_pdr_fm/data/datasets.py",
        repo_root / "bg_pdr_fm/training/train_bg_pdr_fm.py",
    )
    for source_path in source_paths:
        source = source_path.read_text(encoding="utf-8")
        assert not any(path in source for path in removed_paths), source_path


@pytest.mark.parametrize(
    "backend_name",
    ["simple_ddpm", "diffusers_unet_crossattn_fm", "diffusers_crossattn_fm", "legacy_fm"],
)
def test_build_residual_backend_rejects_removed_backend_names(backend_name: str) -> None:
    from bg_pdr_fm.models.residual_backends import build_residual_backend

    with pytest.raises(
        ValueError,
        match=r"Only supported residual backends are: simple_fm, unet_fm_film, direct_predictor",
    ):
        build_residual_backend(backend=backend_name)
