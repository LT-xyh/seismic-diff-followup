"""Tests for the standalone source-submission validator."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from reproducibility.validate_submission import ReleaseValidationError, validate_submission


REPO_ROOT = Path(__file__).resolve().parents[1]


def _run_git(root: Path, *args: str) -> None:
    subprocess.run(["git", *args], cwd=root, check=True, capture_output=True, text=True)


def _write_minimal_repository(root: Path) -> None:
    (root / "reproducibility").mkdir(parents=True)
    (root / ".gitignore").write_text("/reproducibility/generated/\n", encoding="utf-8")
    (root / "README.md").write_text("Standalone source package.\n", encoding="utf-8")
    (root / "source.py").write_text("VALUE = 1\n", encoding="utf-8")
    (root / "config.yaml").write_text("name: synthetic\n", encoding="utf-8")
    (root / "prepare.py").write_text("raise SystemExit(0)\n", encoding="utf-8")
    (root / "train.py").write_text("raise SystemExit(0)\n", encoding="utf-8")
    (root / "evaluate.py").write_text("raise SystemExit(0)\n", encoding="utf-8")
    (root / "smoke.py").write_text("raise SystemExit(0)\n", encoding="utf-8")
    (root / "validate.py").write_text("raise SystemExit(0)\n", encoding="utf-8")
    (root / "test_source.py").write_text("def test_placeholder():\n    assert True\n", encoding="utf-8")
    manifest = {
        "version": 1,
        "source": ["source.py"],
        "configs": ["config.yaml"],
        "entrypoints": {
            "prepare_openfwi": "prepare.py",
            "train": "train.py",
            "evaluate": "evaluate.py",
            "smoke": "smoke.py",
            "validate": "validate.py",
        },
        "tests": ["test_source.py"],
        "documentation": [".gitignore", "README.md", "reproducibility/source_manifest.yaml"],
    }
    (root / "reproducibility" / "source_manifest.yaml").write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="utf-8",
    )
    _run_git(root, "init")
    _run_git(root, "checkout", "-b", "main")
    _run_git(root, "config", "user.name", "Anonymous")
    _run_git(root, "config", "user.email", "anonymous@example.com")
    _run_git(root, "add", ".")
    _run_git(root, "commit", "-m", "Initial anonymous code appendix")


def _amend_initial_commit(root: Path) -> None:
    _run_git(root, "commit", "--amend", "--no-edit")


def test_validate_submission_accepts_anonymous_source_repository(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    report_path = tmp_path / "reports" / "submission.json"

    report = validate_submission(repo_root=tmp_path, output=report_path)

    assert report["status"] == "pass"
    assert report["checks"]["git_history"] == "pass"
    assert report["checks"]["git_references"] == "pass"
    assert report["repository"]["refs"] == ["refs/heads/main"]
    assert json.loads(report_path.read_text(encoding="utf-8"))["status"] == "pass"


def test_validate_submission_rejects_an_extra_local_branch(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    _run_git(tmp_path, "branch", "old-state")

    with pytest.raises(ReleaseValidationError, match="references"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_rejects_an_unexpected_initial_commit_subject(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    _run_git(tmp_path, "commit", "--amend", "-m", "Unexpected initial commit")

    with pytest.raises(ReleaseValidationError, match="commit subject"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_rejects_an_unexpected_initial_commit_identity(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    _run_git(tmp_path, "commit", "--amend", "--no-edit", "--author", "Elsewhere <elsewhere@example.com>")

    with pytest.raises(ReleaseValidationError, match="commit identity"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_rejects_disallowed_text_in_local_git_config(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    token = "co" + "dex"
    _run_git(tmp_path, "config", "--local", "release.note", token)

    with pytest.raises(ReleaseValidationError, match="Git metadata"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_rejects_disallowed_text_in_reachable_git_history(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    token = "co" + "dex"
    _run_git(
        tmp_path,
        "commit",
        "--amend",
        "-m",
        f"Initial anonymous code appendix\n\n{token}",
    )

    with pytest.raises(ReleaseValidationError, match="Git metadata"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_rejects_a_tracked_output_directory(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    artifact = tmp_path / "outputs" / "result.json"
    artifact.parent.mkdir()
    artifact.write_text("{}\n", encoding="utf-8")
    _run_git(tmp_path, "add", "-f", "outputs/result.json")
    _amend_initial_commit(tmp_path)

    with pytest.raises(ReleaseValidationError, match="forbidden tracked path"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_rejects_a_manifest_path_ignored_by_git(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    (tmp_path / ".gitignore").write_text("source.py\n", encoding="utf-8")
    _run_git(tmp_path, "add", ".gitignore")
    _amend_initial_commit(tmp_path)

    with pytest.raises(ReleaseValidationError, match="ignored by Git"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_requires_the_default_report_path_to_be_ignored(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    (tmp_path / ".gitignore").write_text("", encoding="utf-8")
    _run_git(tmp_path, "add", ".gitignore")
    _amend_initial_commit(tmp_path)

    with pytest.raises(ReleaseValidationError, match="default report path is not ignored"):
        validate_submission(repo_root=tmp_path)


def test_validate_submission_rejects_disallowed_text_in_a_tracked_file(tmp_path: Path) -> None:
    _write_minimal_repository(tmp_path)
    token = "co" + "dex"
    (tmp_path / "README.md").write_text(f"{token}\n", encoding="utf-8")
    _run_git(tmp_path, "add", "README.md")
    _amend_initial_commit(tmp_path)

    with pytest.raises(ReleaseValidationError, match="disallowed text"):
        validate_submission(repo_root=tmp_path)


def test_validate_cli_dry_run_uses_the_source_only_validator_surface() -> None:
    result = subprocess.run(
        [sys.executable, "scripts/aaai27/validate.py", "--dry-run"],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert '"profile": "aaai27"' in result.stdout


def test_validate_cli_imports_the_standalone_submission_validator() -> None:
    source = (REPO_ROOT / "scripts" / "aaai27" / "validate.py").read_text(encoding="utf-8")

    assert "validate_submission" in source
    assert "validate_release" not in source
